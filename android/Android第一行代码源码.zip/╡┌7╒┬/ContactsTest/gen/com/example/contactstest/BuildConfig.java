/** Automatically generated file. DO NOT MODIFY */
package com.example.contactstest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}